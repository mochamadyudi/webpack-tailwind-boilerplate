class Store {
  static state = {

  }

}

export default Store
